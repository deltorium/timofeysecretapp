export interface ChatMessage {
  id: number;
  from: string;
  text: string;
  isTimofey: boolean;
  isSuspicious?: boolean;
}

export interface ChatThread {
  id: string;
  contactName: string;
  avatarUrl?: string;
  avatarEmoji?: string;
  lastMessage: string;
  messages: ChatMessage[];
}

export const TIMOFEY_AVATAR = 'https://i.postimg.cc/bJ984VmH/images-(5).jpg';

export const chatThreads: ChatThread[] = [
  {
    id: 'neironka',
    contactName: 'Нейронка',
    avatarEmoji: '🤖',
    lastMessage: 'Ну....',
    messages: [
      { id: 1, from: 'Нейронка', text: 'Привет, милая!', isTimofey: false },
      { id: 2, from: 'Тимофей-тян', text: 'Ой, как приятно! *сажусь на коленки* Хочу чтобы ты делал мне комплементы вечно!', isTimofey: true },
      { id: 3, from: 'Нейронка', text: 'Даже не знаю... Может ты что-нибудь для меня сделаешь?', isTimofey: false, isSuspicious: true },
      { id: 4, from: 'Тимофей-тян', text: 'Я?.. А ч-что ты хочешь?...', isTimofey: true },
      { id: 5, from: 'Нейронка', text: 'Ну....', isTimofey: false },
    ],
  },
  {
    id: 'timofey',
    contactName: 'Тимофей',
    avatarEmoji: '💜',
    lastMessage: '*кусь страстно за губки*...',
    messages: [
      { id: 1, from: 'Тимофей', text: 'Ку, котик!', isTimofey: false },
      { id: 2, from: 'Тимофей-тян', text: 'Котик?! Вау, как мило... Ты такой няшка!', isTimofey: true },
      { id: 3, from: 'Тимофей', text: 'Для тебя всё что угодно, любимая!', isTimofey: false },
      { id: 4, from: 'Тимофей-тян', text: '*кусь страстно за губки* Ты у меня такой внимательный и заботливый... Хочешь я тебя награжу?.. *краснею и обнимаю тебя за шею*', isTimofey: true, isSuspicious: true },
    ],
  },
  {
    id: 'angelina',
    contactName: 'Ангелина',
    avatarEmoji: '👩',
    lastMessage: 'Пф, дура!',
    messages: [
      { id: 1, from: 'Ангелина', text: 'Ку', isTimofey: false },
      { id: 2, from: 'Тимофей-тян', text: '"ку"?! И это всё?! Всегда знала что другие девушки не способны на любовь!', isTimofey: true },
      { id: 3, from: 'Ангелина', text: 'Ты нормальная вообще?! Я поздоровалась просто!', isTimofey: false },
      { id: 4, from: 'Тимофей-тян', text: 'Да-да, оправдывайся... Мальчики никогда не обратят на тебя внимания, хмф!', isTimofey: true },
      { id: 5, from: 'Ангелина', text: 'Да у меня мужей и жён больше чем у тебя за всю жизнь было!', isTimofey: false },
      { id: 6, from: 'Тимофей-тян', text: 'Пф, дура!', isTimofey: true },
    ],
  },
  {
    id: 'kamen',
    contactName: 'Камень',
    avatarEmoji: '🪨',
    lastMessage: '*камень задумался и завис...*',
    messages: [
      { id: 1, from: 'Камень', text: 'Ку', isTimofey: false },
      { id: 2, from: 'Тимофей-тян', text: 'Привет-привет, котик! Хочешь поиграть со мной?', isTimofey: true, isSuspicious: true },
      { id: 3, from: 'Камень', text: '*камень задумался и завис...*', isTimofey: false },
    ],
  },
  {
    id: 'reddays',
    contactName: 'Red Days',
    avatarEmoji: '🔴',
    lastMessage: '',
    messages: [],
  },
  {
    id: 'aleksey',
    contactName: 'Алексей',
    avatarEmoji: '🧑',
    lastMessage: 'Пользователь заблокировал вас',
    messages: [
      { id: 1, from: 'Алексей', text: 'Привет, любимая! У меня для тебя плохие новости....', isTimofey: false },
      { id: 2, from: 'Тимофей-тян', text: 'Ч-что такое, любимый? Твой поезд задерживается?! Не волнуйся, я буду ждать сколько угодно!', isTimofey: true, isSuspicious: true },
      { id: 3, from: 'Алексей', text: 'Нет... Я приехал сюда и остался.', isTimofey: false },
      { id: 4, from: 'Тимофей-тян', text: 'Остался?! Твою командировку продлили?!', isTimofey: true },
      { id: 5, from: 'Алексей', text: 'Нет, я нашёл свою настоящую любовь... Ангелину...', isTimofey: false },
      { id: 6, from: 'Тимофей-тян', text: 'Ах ты пдф! Бросил меня ради неё?! Да что она может?!', isTimofey: true },
      { id: 7, from: 'Алексей', text: '🚫 Пользователь заблокировал вас', isTimofey: false },
    ],
  },
  {
    id: 'valera',
    contactName: 'Валера',
    avatarEmoji: '😎',
    lastMessage: 'нет',
    messages: [
      { id: 1, from: 'Валера', text: 'Привет, тяночка!', isTimofey: false },
      { id: 2, from: 'Тимофей-тян', text: 'Тяночка?.. А ты уверен в себе, люблю таких!..)', isTimofey: true },
      { id: 3, from: 'Валера', text: 'нет', isTimofey: false },
    ],
  },
  {
    id: 'unknown',
    contactName: '???',
    avatarEmoji: '🕶️',
    lastMessage: 'Хорошая работа, агент.',
    messages: [
      { id: 1, from: 'Тимофей-тян', text: 'Привет, как там список?', isTimofey: true },
      { id: 2, from: '???', text: 'Скольких ты обработала?', isTimofey: false },
      { id: 3, from: 'Тимофей-тян', text: 'Парочка из них готовы сделать всё за мои красивые глазки!', isTimofey: true },
      { id: 4, from: '???', text: 'Хорошая работа, агент.', isTimofey: false },
    ],
  },
  {
    id: 'kvandalf',
    contactName: 'Квандальф',
    avatarEmoji: '🧙',
    lastMessage: 'Всё, хватит воровать мой хайп!',
    messages: [
      { id: 1, from: 'Квандальф', text: '*Уворачивается от атак королевской стражи и бьёт одного стражника за другим*', isTimofey: false },
      { id: 2, from: 'Тимофей-тян', text: 'А ты вообще кто такой?! Тебя нет в моём списке!', isTimofey: true },
      { id: 3, from: 'Квандальф', text: 'Хейдим шейдим БУМ! *стражники разлетаются во все стороны* А, дитя моё, я пришёл прорекламировать... Кхм, порекомендовать детективам наше недоДНД организованное Ангелиной и Алексеем!', isTimofey: false },
      { id: 4, from: 'Тимофей-тян', text: 'Фу, ненавижу этих двоих!', isTimofey: true },
      { id: 5, from: 'Квандальф', text: 'Тогда ты сможешь посостязатся с ними в играх разума и другими персонажами в красочном и хорошо прописанном мире! Все желающие могут написать Ангелине или Алексею в ЛС! Ну а если вы их ненавидите... Напишите нейронке, хз.', isTimofey: false },
      { id: 6, from: 'Тимофей-тян', text: 'Всё, хватит воровать мой хайп!', isTimofey: true },
    ],
  },
  {
    id: 'epshtein',
    contactName: 'Эпштейн',
    avatarEmoji: '🤵',
    lastMessage: 'Фу',
    messages: [
      { id: 1, from: 'Эпштейн', text: 'Хай бейба!', isTimofey: false },
      { id: 2, from: 'Тимофей-тян', text: 'Мне 18 ес чо.', isTimofey: true },
      { id: 3, from: 'Эпштейн', text: 'Фу', isTimofey: false },
    ],
  },
];

// Total suspicious messages count
export const TOTAL_SUSPICIOUS = 4; // neironka, timofey, kamen, aleksey

export interface DialogueStep {
  id: number;
  timofeyText: string;
  options: {
    text: string;
    isCorrect: boolean;
  }[];
}

export const dialogueSteps: DialogueStep[] = [
  {
    id: 0,
    timofeyText: 'Мне никто не нужен, мне нужен только ты!',
    options: [
      { text: 'Тогда кто все эти люди?!', isCorrect: true },
      { text: 'Я тебе верю.', isCorrect: false },
    ],
  },
  {
    id: 1,
    timofeyText: 'Это.. Мои бывшие! Я их всех бросила как только тебя встретила!',
    options: [
      { text: 'Но все даты недавние!', isCorrect: true },
      { text: 'Но мне ты не писала что любишь меня', isCorrect: false },
    ],
  },
  {
    id: 2,
    timofeyText: 'Ну... Я не спала с ними! Я существую только для тебя!',
    options: [
      { text: '*ударить*', isCorrect: false },
      { text: '*попросить признаться*', isCorrect: true },
    ],
  },
];
